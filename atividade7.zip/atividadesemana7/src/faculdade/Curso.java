package faculdade;
import java.util.ArrayList;

public class Curso {
	private String nome;
	private String codigo;
	
	ArrayList <Disciplina> materia = new ArrayList<Disciplina>();
	
	Curso(String n, String c) {
		this.nome = n;
		this.codigo = c;
	}
}
