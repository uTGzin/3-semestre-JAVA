package faculdade;

public abstract class Pessoa {
	private String nome;
	private Endereco e;
	
	Pessoa(String n) {
		this.nome = n;
	}
	
	public String getNome( ) {
		return this.nome;
	}
	
		public Endereco getEndereco() {
		return this.e;
	}
	
	public void setEndereco(Endereco e) {
		this.e = e;
	}

	public abstract String mostraDados();
}