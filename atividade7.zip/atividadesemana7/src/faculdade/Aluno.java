package faculdade;

public class Aluno extends Pessoa{
	private int matricula;
	private int ano;
	private Curso c;
	
	Aluno(String n, int m, int a) {
		super(n);
		this.matricula = m;
		this.ano = a;
	}

	public Curso getC() {
		return this.c;
	}

	public void setC(Curso c) {
		this.c = c;
	}

	public String mostraDados() {
		return "Matricula do discente : "+matricula + "\n"+getNome()+" vinculado em "+ano+"\n";
	}
}
