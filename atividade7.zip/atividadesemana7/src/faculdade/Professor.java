package faculdade;

public class Professor extends Pessoa{
	private int matricula;
	private String formacao;
	
	Professor(String n, int m, String f) {
		super(n);
		this.matricula = m;
		this.formacao = f;
	}
	
	public String mostraDados() {
		return "Matricula do afiliado: " + this.matricula + "\n"+getNome()+" professor no Curso : " + this.formacao;
	}
}