package faculdade;

public class Main {
	public static void main(String[] args) {
		Curso c = new Curso("E/S","202105");
		Disciplina d = new Disciplina(202105, "Calculo 1", 20);
		c.materia.add(d);
		d = new Disciplina(202106, "Probabilidade e estatistica",20);
		c.materia.add(d);
		Aluno a = new Aluno("Luiz", 202105045,2021);
		Endereco e = new Endereco("Julio Cesar", 00, "Jardim Planalto");
		a.setEndereco(e);
		a.setC(c);
		Professor p = new Professor("Juliano",198005,"Engenharia de Software");
		System.out.println(a.mostraDados()+"\n"+p.mostraDados());
		
	}
}
