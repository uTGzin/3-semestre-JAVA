package faculdade;

public class Endereco {
	private String rua;
	private int numero;
	private String bairro;
	
	Endereco(String r, int n, String b){
		this.rua = r;
		this.numero = n;
		this.bairro = b;
	}
}
