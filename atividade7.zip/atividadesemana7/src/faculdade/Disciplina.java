package faculdade;

public class Disciplina {
	private int codigo;
	private String nome;
	private int creditos;
	
	Disciplina(int co, String n, int c) {
		this.codigo = co;
		this.nome = n;
		this.creditos = c;
	}
}
