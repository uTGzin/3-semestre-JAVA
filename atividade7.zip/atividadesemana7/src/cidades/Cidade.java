package cidades;
import java.util.ArrayList;

public class Cidade {
	private String codigo;
	private String nome;
	private int populacao;
	private int area;
	ArrayList <Cidade> fronteira = new ArrayList<Cidade>();
	private float densidade;
	
	//A)
	Cidade(String c, String n, int a) {
		this.codigo = c;
		this.nome = n;
		this.area = a;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getNome() {
		return nome;
	}

	public int getPopulacao() {
		return populacao;
	}

	public void setPopulacao(int p) {
		this.populacao = p;
		this.densidade = this.populacao/this.area;
	}

	public int getArea() {
		return area;
	}
	
	public void setFronteira(Cidade a) {
		this.fronteira.add(a);
		a.fronteira.add(this);
	}
	
	//B)
	public boolean comparaIguais(Cidade c) {
		return this.equals(c);
	}
	//C)
	public boolean isLimitrofe(Cidade b) {
		for(Cidade a : fronteira) {
			if (a.nome == b.nome) {
				return true;
			}
		}
		return false;
		
		//return this.fronteira.contains(b);
	}
	//D)
	public String densidadeDemografica() {
		
		String a = "Povoacao ";
		if (densidade > 500) { 
			a += "Elevada : ";
		}
		else if (densidade < 500 || densidade > 100) {
			a += "Regular : ";
		}
		else {
			a = "Baixa : ";
		}
		return a + (int)densidade+" habitantes/km";
	}
	
	//E)
	public void fronteirasIguais(Cidade c) {
		String a = "cidades em comum = ";
		for (int i = 0;i < this.fronteira.size();i++) {
			for (int k = 0;k < c.fronteira.size();k++) {
				if (this.fronteira.get(i).codigo == c.fronteira.get(k).codigo) {
					a += this.fronteira.get(i).nome + " ";
				}
				
			}
		}System.out.println(a+".");
	}
	//F)
	public String mostraDados() {
		String s = "Cidade "+nome+"/"+codigo+"\npossui "+area+"KM quadrados.\n";
		s += "populacao : "+populacao+"\napresentando : "+densidade+" habitantes/km";
		return s;
	}
}