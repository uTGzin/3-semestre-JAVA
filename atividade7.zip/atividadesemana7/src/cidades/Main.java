package cidades;

public class Main {
	public static void main(String[] args) {
		Cidade Goiania = new Cidade("GYN","Goiania",2500);
		Cidade Anapolis = new Cidade("ANP","Anapolis",1900);
		Goiania.setFronteira(Anapolis);
		Goiania.setPopulacao(120000);
		System.out.println(Goiania.densidadeDemografica()+"\n"+Goiania.mostraDados());
		Cidade Trindade = new Cidade("TRI","Trindade",1500);
		//para teste da função isLimitrofe é necessario comentar a proxima linha!!
		//Trindade.setFronteira(Goiania);
		Trindade.setFronteira(Anapolis);
		Anapolis.fronteirasIguais(Trindade);
		if(Goiania.comparaIguais(Trindade)) {
			System.out.println("Sao a mesma cidade");
		}
		else {
			System.out.println("Sao cidades diferentes");
		}
		if(Goiania.isLimitrofe(Trindade)) {
			System.out.println("fazem fronteira");
		}
		else {
			System.out.println("nao sao vizinhas");
		}
	}
}
