package cidades;
//F)
public interface Publicavel {

	public String mostraDados();
}
