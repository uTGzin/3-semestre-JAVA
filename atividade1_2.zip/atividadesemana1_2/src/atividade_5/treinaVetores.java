package atividade_5;

import javax.swing.JOptionPane;

public class treinaVetores {
	public static void main(String[] args) {
		int[] numeros = new int[10];
		int[] numerosInversos = new int [10];
		int[] numerosQuadrados = new int [10];
		int soma = 0;
		int media;
		for (int i = 0;i < numeros.length;i++) {
			int n = Integer.parseInt(JOptionPane.showInputDialog("selecione o numero "+(i+1)));
			numeros[i] = n;
		}
		for (int i = 0;i < numeros.length;i++) {
			soma += numeros[i];
		}
		media = soma/10;
		int k = 9;
		for(int i = 0;i < numeros.length;i++) {
			numerosInversos[k] = numeros[i];
			k--;
		}
		for (int i = 0;i < numeros.length;i++) {
			numerosQuadrados[i] = (int)Math.pow(numeros[i],2);
		}
		System.out.println("soma : "+soma);
		System.out.println("media : "+media);
		for (int i = 0;i < numeros.length;i++) {
			System.out.print(numeros[i]+" ");
		}
		System.out.println();
		for (int i = 0;i < numeros.length;i++) {
			System.out.print(numerosInversos[i]+" ");
		}
		System.out.println();
		for (int i = 0;i < numeros.length;i++) {
			System.out.print(numerosQuadrados[i]+" ");
		}
	}
}
