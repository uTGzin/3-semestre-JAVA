package atividade_3;

public class Ordenar {
	private int n1;
	private int n2;
	private int aux;
	
	Ordenar(int n1, int n2){
		this.n1 = n1;
		this.n2 = n2;
		if (this.n1 > this.n2) {
		}
		else {
			aux = this.n1;
			this.n1 = this.n2;
			this.n2 = this.aux;
		}
	}
	
	public String toString() {
		String s = "numero maior = "+n1+",numero menor = "+n2;
		return s;
	}
}
