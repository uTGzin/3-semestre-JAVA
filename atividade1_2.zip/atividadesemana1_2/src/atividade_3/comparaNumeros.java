package atividade_3;

import javax.swing.JOptionPane;

public class comparaNumeros {
	public static void main(String[] args) {
		String numero = JOptionPane.showInputDialog("selecione 1° numero : ");
		int n1 = Integer.parseInt(numero);
		numero = JOptionPane.showInputDialog("selecione o 2° numero : ");
		int n2 = Integer.parseInt(numero);
		Ordenar o = new Ordenar(n1, n2);
		System.out.println(o.toString());
	}
}
