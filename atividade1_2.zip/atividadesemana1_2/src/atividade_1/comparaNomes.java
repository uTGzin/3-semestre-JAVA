package atividade_1;

import javax.swing.JOptionPane;

public class comparaNomes {
	public static void main(String[] args) {
		String nome1 = JOptionPane.showInputDialog("digite o 1° nome :");
		int tamNome1 = nome1.length();
		String nome2 = JOptionPane.showInputDialog("digite o 2° nome :");
		int tamNome2 = nome2.length();
		boolean result;
		result = nome1.equals(nome2);
		System.out.println("tamanho da primeira palavra : "+tamNome1);
		System.out.println("tamanho da segunda palavra : "+tamNome2);
		System.out.println(result ? "iguais" : "diferentes");
	}
}