package atividade_2;
import javax.swing.JOptionPane;

public class arredondaDecimal {
	public static void main(String[] args) {
		String s = JOptionPane.showInputDialog("insira o valor decimal");
		float decimal = Float.parseFloat(s);
		System.out.println("valor arredondado = "+Math.round(decimal));
		System.out.println("valor arredondado = "+Math.ceil(decimal));
		System.out.println("valor arredondado = "+Math.floor(decimal));
	}
}
