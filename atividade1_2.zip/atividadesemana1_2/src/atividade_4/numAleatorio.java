package atividade_4;
import java.util.Random;

public class numAleatorio {
	public static void main(String[] args) {
		Random l = new Random();
		System.out.println(l.nextInt(101));
	}
}
