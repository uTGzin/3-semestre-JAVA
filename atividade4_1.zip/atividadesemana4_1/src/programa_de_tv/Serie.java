package programa_de_tv;

public class Serie extends ProgramaTV{
	private int temporadasTotais;
	private int episodiosTotais;
	
	
	Serie(String nome, String categoria, int temp, int ep){
		super(nome, categoria);
		this.temporadasTotais = temp;
		this.episodiosTotais = ep;
	}


	public int getTemporadasTotais() {
		return temporadasTotais;
	}


	public void setTemporadasTotais(int temporadasTotais) {
		this.temporadasTotais = temporadasTotais;
	}


	public int getEpisodiosTotais() {
		return episodiosTotais;
	}


	public void setEpisodiosTotais(int episodiosTotais) {
		this.episodiosTotais = episodiosTotais;
	}
	
	public String toString() {
		String serie =  "Temporadas totais : " + temporadasTotais + "\n";
		serie = serie + "episodios disponiveis : " + episodiosTotais +"\n";
		return super.toString() + serie;
	}

}
