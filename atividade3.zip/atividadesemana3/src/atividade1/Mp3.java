package atividade1;
import java.util.Scanner;

public class Mp3 {
       public static void main(String[] args) {
    	      Scanner sc = new Scanner(System.in);
    	      //primeira musica
    	      System.out.println("insira o nome da musica");
	          Musica m1 = new Musica(sc.nextLine());
	          Compositor c1 = new Compositor("Cassio");
	          m1.setComp(c1);	         
	          System.out.println("insira a nacionalidade do compositor da 1° musica");
	          m1.comp.setNacionalidade(sc.nextLine()) ;
	          System.out.println("insira o tipo de musica");
	          m1.setTipo(sc.nextLine());
	          System.out.println("insira o ano da 1° musica");
	          m1.setAno(sc.nextInt());
	          sc.nextLine();
	          System.out.println("Musica : "+m1.getNome()+" - "+m1.getTipo()+" - \nfeita por : "+m1.comp.nomeComp+"("+m1.comp.nacionalidade+") em "+m1.ano+"\n\n");
              //proxima musica
	          Musica m2 = new Musica("amanhecer");
	          m2.comp = c1;
	          System.out.println("insira o tipo de musica");
	          m2.tipo = sc.nextLine();
	          System.out.println("insira o ano da 2° musica");
	          m2.ano = sc.nextInt();
	          sc.nextLine();
	          System.out.println("Musica : "+m2.nome+" - "+m2.tipo+" - \nfeita por : "+m2.comp.nomeComp+"("+m1.comp.nacionalidade+") em "+m2.ano+"\n\n");
              //ultima musica
	          Musica m3 = new Musica("entardecer");
	          m3.comp = c1;
	          m3.tipo = ("techno");
	          System.out.println("insira o ano da 3° musica");
	          m3.ano = sc.nextInt();
	          sc.nextLine();
	          System.out.println("Musica : "+m3.nome+" - "+m3.tipo+" - \nfeita por : "+m3.comp.nomeComp+"("+m1.comp.nacionalidade+") em "+m3.ano+"\n\n");
	         	      
       }
}
