package atividade1;

public class Compositor {
       private String nomeComp;
       private String nacionalidade;

       
       public void setNomeComp(String a) {
    	      this.nomeComp = a;
       }
       
       public void setNacionalidade(String a) {
    	      this.nacionalidade = a;
       }
       
       public String getNomeComp() {
    	      return nomeComp;
       }
       
       public String getNacionalidade() {
    	      return nacionalidade;
       }
       Compositor(String n) {
    	          this.nomeComp = n;
       }
}
