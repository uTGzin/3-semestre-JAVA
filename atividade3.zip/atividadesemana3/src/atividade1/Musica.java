package atividade1;

public class Musica {
       private String nome;
       private String tipo;
       private int ano;
       private Compositor comp;
       
       public void setNome(String n) {
    	      this.nome = n;
       }
       
       public void setTipo(String t) {
    	      this.tipo = t;
       }
        
       public void setAno(int a) {
    	      this.ano = a;
       }
       
       public void setComp(Compositor a) {
    	      this.comp = a;
       }
       
       public String getNome() {
    	      return nome;
       }
       
       public String getTipo() {
    	      return tipo;
       }
       
       public int getAno() {
    	      return ano;
       }
       
       public Compositor getComp() {
    	      return comp;
       }
       
       Musica(String n) {
    	     this.nome = n;
       }
}