package atividadesemana4_3;

public class Item {
	private String titulo;
	private int ano;
	private String duracao;
	private String comentarios;
	
	Item(String t, int a, String d, String c) {
		this.titulo = t;
		this.ano = a;
		this.duracao = d;
		this.comentarios = c;
	}
	
	public void setComentarios(String c) {
		this.comentarios = c;
	}
	
	public String getComentarios() {
		return this.comentarios;
	}
	
	public String toString() {
		String Item = "titulo : "+this.titulo+"\n"+"lancamento : "+this.ano+"\n";
		Item = Item + "duracao : "+this.duracao+"\n"+"avaliacoes : "+this.comentarios+"\n";
		return Item;
	}
}
