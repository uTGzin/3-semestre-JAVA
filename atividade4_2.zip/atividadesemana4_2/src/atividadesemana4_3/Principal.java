package atividadesemana4_3;
import java.util.ArrayList;

public class Principal {
	public static void main(String[] args) {
		ArrayList <Item> midia = new ArrayList <Item>();
		
		CD cd = new CD("titulo 1", 2001, "horario 1", "comentario 1", "artista 1", 001);
		midia.add(cd);
		
		Filme f = new Filme("titulo 2", 2002, "horario 2", "comentario 2","diretor 2");
		midia.add(f);
		
		Jogo j = new Jogo("titulo 3", 2003, "horario 3", "comentario 3", 200003, "plataforma 3");
		midia.add(j);
		
		cd = new CD("titulo 4", 2004, "horario 4", "comentario 4", "artista 4", 004);
		midia.add(cd);
		
		f = new Filme("titulo 5", 2005, "horario 5", "comentario 5","diretor 5");
		midia.add(f);
		
		j = new Jogo("titulo 6", 2006, "horario 6", "comentario 6", 200006, "plataforma 6");
		midia.add(j);
		
		cd = new CD("titulo 7", 2007, "horario 7", "comentario 7", "artista 7", 007);
		midia.add(cd);
		
		f = new Filme("titulo 8", 2008, "horario 8", "comentario 8","diretor 8");
		midia.add(f);
		
		j = new Jogo("titulo 9", 2009, "horario 9", "comentario 9", 200009, "plataforma 9");
		midia.add(j);
		
		cd = new CD("titulo 10", 2010, "horario 10", "comentario 10", "artista 10", 10);
		midia.add(cd);
		
		for (int i=0;i<midia.size();i++) {
			System.out.println(midia.get(i));
			System.out.println();
		}
	}
}
