package atividadesemana4_3;

public class Jogo extends Item{
	private int numPlayers;
	private String plataforma;
	
	
	Jogo(String n, int a, String d, String c, int num, String pl) {
		super(n, a, d, c);
		this.numPlayers = num;
		this.plataforma = pl;
	}
	
	public void setPlayers(int num) {
		this.numPlayers = num;
	}
	
	public int getPlayers() {
		return this.numPlayers;
	}
	
	public String getPlataforma() {
		return this.plataforma;
	}
	
	public String toString() {
		String jogo = "numero de jogadores online : "+numPlayers+" conectados na plataforma"+plataforma+"\n";
		return super.toString() + jogo;
	}
}
