package atividadesemana4_3;

public class Filme extends Item{
	private String diretor;
	
	Filme(String n, int a, String d, String c, String di) {
		super(n, a, d, c);
		this.diretor = di;
	}
	
	public String getDiretor() {
		return this.diretor;
	}
	
	public String toString() {
		String filme = "Diretor : "+diretor+"\n";
		return super.toString() + filme;
	}
}
