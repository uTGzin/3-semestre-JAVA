package atividadesemana4_3;

public class CD extends Item{
	private String artista;
	private int faixas;

	CD(String n, int a, String d, String c, String ar, int f) {
		super(n, a, d, c);
		this.artista = ar;
		this.faixas = f;
	}
	
	public String getArtista() {
		return this.artista;
	}
	
	public int getFaixas() {
		return this.faixas;
	}
	
	public String toString() {
		String CD = "Cantor(a) : "+this.artista+"\n";
		CD = CD + "numero de musicas : "+this.faixas+"\n";
	    return super.toString() + CD;
	}
}
