package main;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList <Funcionarios> funcoes = new ArrayList <Funcionarios>();
		Funcionarios f = new Horistas("Adamastor ", "Braga", 80, 14.0);
		funcoes.add(f);
		Funcionarios fu = new Horistas("Betina ", "Costa", 65, 21.0);
		funcoes.add(fu);
		Funcionarios fun = new Administradores("Carlin ", "Doria", 2400.00);
		funcoes.add(fun);
		Funcionarios func = new Administradores("Dantas ", "Elias", 2500.00);
		funcoes.add(func);
		Funcionarios funci = new Administradores("Emanuel ", "Fagundes", 3500.00);
		funcoes.add(funci);
		Funcionarios funcio = new Administradores("Fatima ", "Guedes", 1950.00);
		funcoes.add(funcio);
		Funcionarios funcion = new Comissionados("Giullia ", "Hipolitas", 1500.00, 32, 9.00);
		funcoes.add(funcion);
		Funcionarios funciona = new Comissionados("Heraldino ", "Isthudei", 1200.00, 60, 15.00);
		funcoes.add(funciona);
		Funcionarios funcionar = new Comissionados("Ilana ", "Jussaria", 1500.00, 45, 10.00);
		funcoes.add(funcionar);
		Funcionarios funcionari = new Gerentes("Heraldino", "de Jesus", 3200.00, 600.00);
		funcoes.add(funcionari);
	
		for(int i = 0;i<funcoes.size();i++) {
			System.out.println(funcoes.get(i).toString());
		}
	}
}
