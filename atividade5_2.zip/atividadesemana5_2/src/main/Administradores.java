package main;

public class Administradores extends Funcionarios{
	private Double salarioMensal = 0.0;
	
	public Administradores(String n, String s, Double sa) {
		super(n, s);
		this.salarioMensal = sa;
	}
	
	public void ajusteSalarial(Double sa1) {
		System.out.println("salario atualizado de " + this.salarioMensal +"para" + sa1);
		this.salarioMensal = sa1;
	}
	
	public String toString() {
		String to;
		to = "Funcao : Administrador \nValor atual de salario recebido = " + this.salarioMensal + "\n";
		return super.toString() + to;
	}
}
