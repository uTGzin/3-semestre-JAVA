package main;

public abstract class Funcionarios {
	private String nome;
	private String sobrenome;
	
	Funcionarios(String n, String s) {
		this.nome = n;
		this.sobrenome = s;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return this.sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String toString() {
		String to;
		to = "nome completo = " + nome + sobrenome + "\n";
		return to;
	}
	
	
}
