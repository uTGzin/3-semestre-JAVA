package main;

public class Comissionados  extends Funcionarios{
	private Double salarioMensal = 0.0;
	private int totalVendas = 0;
	private Double percentualComissional = 0.0;
	private Double salarioTotal = 0.0;
	
	public Comissionados(String n, String s, Double sM, int tV, Double pC) {
		super(n, s);
		this.salarioMensal = sM;
		this.totalVendas = tV;
		this.percentualComissional = pC;
		calculaSalario();
	}

	public Double getSalarioMensal() {
		return this.salarioMensal;
	}

	public void setSalarioMensal(Double salarioMensal) {
		this.salarioMensal = salarioMensal;
		calculaSalario();
	}

	public int getTotalVendas() {
		return this.totalVendas;
	}

	public void setTotalVendas(int tV) {
		this.totalVendas = tV;
		calculaSalario();
	}

	public Double getPercentualComissional() {
		return this.percentualComissional;
	}

	public void setPercentualComissional(Double pC) {
		this.percentualComissional = pC;
		calculaSalario();
	}
	
	public void calculaSalario() {
		this.salarioTotal = salarioMensal + (totalVendas*percentualComissional);
	}
	
	public String toString() {
		String to;
		to = "Funcao : Comissionado \nValor atual de salario recebido = " + this.salarioTotal + "\n";
		to = to + "Receita fracionada : "+salarioMensal+" mensais + "+(totalVendas*percentualComissional);
		to = to + " de comissoes por "+totalVendas+" vendas\n";
		return super.toString() + to;
	}
	
}
