package main;

public class Gerentes  extends Funcionarios{
	private Double salarioMensal= 0.0;
	private Double bonificacao = 0.0;
	private Double salarioTotal = 0.0;
	
	Gerentes(String n, String s, Double sM, Double b) {
		super(n, s);
		this.salarioMensal = sM;
		this.bonificacao = b;
		calculaSalario();
	}
	
	public Double getSalarioMensal() {
		return this.salarioMensal;
	}

	public void setSalarioMensal(Double sM) {
		this.salarioMensal = sM;
		calculaSalario();
	}

	public Double getBonificacao() {
		return bonificacao;
	}

	public void setBonificacao(Double b) {
		this.bonificacao = b;
		calculaSalario();
	}

	public void calculaSalario() {
		this.salarioTotal = salarioMensal + bonificacao;
	}

	
	public String toString() {
		String to;
		to  = "Funcao : Gerente \nValor atual de salario recebido = " + this.salarioTotal + "\n";
		return super.toString() + to;
	}
}
