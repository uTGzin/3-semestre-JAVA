package main;

public class Horistas  extends Funcionarios{
	private int horas = 0;
	private Double valorHoras = 0.0;
	private Double salarioTotal = 0.0;
	
	Horistas(String n, String s, int h, Double v) {
		super(n, s);
		this.horas = h;
		this.valorHoras = v;
		calculaSalario();
	}
	
	public int getHoras() {
		return this.horas;
	}

	public void setHoras(int h) {
		this.horas = h;
	}

	public Double getValorHoras() {
		return this.valorHoras;
	}

	public void setValorHoras(Double v) {
		this.valorHoras = v;
	}

	public void calculaSalario() {
		this.salarioTotal = horas*valorHoras;
	}
	
	public String toString() {
		String to;
		to =  "Funcao : Horista \nValor atual de salario recebido = " + this.salarioTotal + "\n";
		to = to + "Horas trabalhadas : " + horas + " no valor de "+valorHoras+" a hora\n";
		return super.toString() + to;
	}
}