package atividade_1;

public class Produto {
       int codigo;
       String nome;
       int qtd;
       String tipo;
       double valor;
       
       Produto (int codigo) {
    	        this.codigo = codigo;
       }
       
       Produto (int codigo, String nome) {
    	        this.codigo = codigo;
    	        this.nome = nome;
       }
       
       Produto (int codigo, String nome, int qtd) {
    	        this.codigo = codigo;
    	        this.nome = nome;
    	        this.qtd = qtd;
       }
       
       Produto (int codigo, String nome, int qtd, String tipo, double valor) {
    	        this.codigo = codigo;
    	        this.nome = nome;
    	        this.qtd = qtd;
    	        this.tipo = tipo;
    	        this.valor = valor;
       }
       
       boolean vender(int n) {
    	       if (this.qtd > n) {
  	    	       this.qtd = this.qtd - n;
    	    	   return true;
    	           }
    	       else {
    	    	     return false;
    	       }
       }
       
       void comprar(int n, double l) {
    	    qtd = qtd+n;
    	    valor = l;
       }
       
       void comprar(int n) {
   	    qtd = qtd+n;
       }
       
       void consultar() {
    	    System.out.println("Codigo: "+ codigo + " - Nome: " + nome + " - Tipo: " + tipo + " - Valor: " + valor + " - quantidade: " + qtd);
       }
       
       void inserir(String nome2, int qtd2, String tipo2, double valor2) {
    	    this.nome = nome2;
    	    this.qtd = qtd2;
    	    this.tipo = tipo2;
    	    this.valor = valor2;
       }
       
       boolean igual(Produto p) {
    	       if (this.nome.equals(p.nome) && this.tipo.equals(p.tipo)) {
   			       return true;
    	       }
    	       return false;
       }
}
