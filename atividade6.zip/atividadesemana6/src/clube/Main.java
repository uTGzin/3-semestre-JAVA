package clube;
import java.util.ArrayList;
import javax.swing.JOptionPane; 

public class Main {
	public static void main(String[] args) {
		ArrayList <Titular> titular = new ArrayList<Titular>();
		char cadastro = JOptionPane.showInputDialog("cadastrar titular\ns/S - sim.\nn/N - nao.").charAt(0);
		while(cadastro == 's' || cadastro == 'S'){
			String n = JOptionPane.showInputDialog("adicione o nome do titular :");
			String idade = JOptionPane.showInputDialog("indique a idade :");
				int i = Integer.parseInt(idade);
			char s = JOptionPane.showInputDialog("especifique sexo:\nM - masculino \nF - feminino").charAt(0);
			String codigo = JOptionPane.showInputDialog("indique o codigo do titular");
				int t = Integer.parseInt(codigo);
			Titular T = new Titular(n, i, s, t);
				titular.add(T);
				cadastro = JOptionPane.showInputDialog("cadastrar mais um titular titular ?\nsim.\nnao.").charAt(0);				
			}
		
		//adicionar dependentes
		for (int k = 0;k < titular.size();k++) {
			String qtdDep = JOptionPane.showInputDialog("esse titular : ("+ titular.get(k).getNome() +") possui quantos dependentes ?");
				int q = Integer.parseInt(qtdDep);
			titular.get(k).setDep(q);
				for (int l = 0;l < q;l++) {
					String n = JOptionPane.showInputDialog("adicione o nome do dependente :");
					String idade = JOptionPane.showInputDialog("indique a idade :");
						int i = Integer.parseInt(idade);
					char s = JOptionPane.showInputDialog("especifique sexo:\nM \nF").charAt(0);
					String tipo = JOptionPane.showInputDialog("indique o tipo de dependente\n1 - filhos\n2 - companheiro\n3 - outros");
						int ti = Integer.parseInt(tipo);
					Dependente D = new Dependente(n,i,s,ti);
					titular.get(k).associarDependentes(D);
				}
		}
		
		
		//calcular mensalidade
		for(int k = 0;k < titular.size();k++) {
			System.out.println(titular.get(k).toString());
			if (titular.get(k).getDep() > 0) {
					System.out.println(titular.get(k).D.toString());
			}
			System.out.println("mensalidade = "+titular.get(k).calculaMensal());
		}
		
		/*for (int k = 0;k < titular.size();k++) {
			System.out.println(titular.get(k).toString());
			}*/
	}
}