package clube;

public class Dependente extends Socio{
	private int tipo;
	
	Dependente(String n, int i, char s,int t) {
		super(n, i, s);
		this.tipo = t;
	}
	
	public void setTipo(int t) {
		this.tipo = t;
	}
	
	public int getTipo() {
		return this.tipo;
	}
	
	public Double calculaMensal() {
		Double r = 0.0;
		if (tipo == 1 || tipo == 2) {
			if (getIdade() <= 10) {
				r = 100.00;
			}
			
			else if(getIdade() <=21) {
				r = 150.00;
			}
			
			else if(getIdade() <=65) {
				r = 200.00;
			}
			
			else {
				r = 80.00;
			}
		}
		
		else if (tipo == 3) {
			if (getIdade() >= 65) {
				r = 250.00;
			}
			else {
				r = 150.00;
			}
		}
		return r;
	}
	
	public String toString() {
		String i = "Dependente tipo " + getTipo() + ": " + getNome() + " " + getIdade()+" anos";
		return i;
	}
}
