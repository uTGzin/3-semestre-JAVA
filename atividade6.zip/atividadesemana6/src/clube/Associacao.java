package clube;

public interface Associacao {
	
	public void associarDependentes(Dependente i);
}
