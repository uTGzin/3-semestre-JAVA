package clube;
import java.util.ArrayList;

public class Titular extends Socio implements Associacao{
	private int numTitulo;
	private int dep = 0;
	ArrayList <Dependente> D = new ArrayList<Dependente>();
	
	
	Titular(String n, int i, char s, int t) {
		super(n, i, s);
		this.numTitulo = t;
	}

	public void setNumTitulo(int t) {
		this.numTitulo = t;
	}
	
	public int getNumTitulo() {
		return this.numTitulo;
	}
	
	public void setDep(int d) {
		this.dep = d;
	}
	
	public int getDep() {
		return this.dep;
	}

	public void associarDependentes(Dependente d) {
		D.add(d);
	}
	
	public Double calculaMensal() {
		Double r = 0.0;
		if (getIdade() >= 21 && getIdade() <= 65) {
			r = 500.00;
		}
		else if (getIdade() > 65) {
			r = 200.00;
		}
		if (this.dep > 0) {
				for (int l = 0;l < dep;l++) {
					r = r + D.get(l).calculaMensal();
				}
		}
		return r;
	}
	
	public String toString() {
		String i = "Titular : " + getNome() + " " + getIdade()+" anos\n" + "codigo de associado : " + numTitulo;
		return i;
	}
}
