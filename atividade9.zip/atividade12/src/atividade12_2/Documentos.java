package atividade12_2;

public abstract class Documentos {
	private int numero;
	private String remetente;
	
	Documentos(int n, String r) {
		this.numero = n;
		this.remetente = r;
	}
}
