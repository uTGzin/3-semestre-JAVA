package atividade12_2;

public abstract class Fabrica {
	public abstract Documentos criaDocumentos(int numero, String remetente);
}
