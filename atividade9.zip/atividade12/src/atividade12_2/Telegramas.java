package atividade12_2;

public class Telegramas extends Documentos{

	Telegramas(int n, String r) {
		super(n, r);
	}
}
