package atividade12_2;

public class FabricaDocumentos extends Fabrica{

	public Documentos criaDocumentos(int numero, String remetente) {
	}
}
