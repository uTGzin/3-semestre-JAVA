package atividade12_2;

public class CadastroDocumento {
	public static void main(String args[]) {
		
	}
}
