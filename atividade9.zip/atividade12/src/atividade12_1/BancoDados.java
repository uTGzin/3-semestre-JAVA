package atividade12_1;

public final class BancoDados {
	public static BancoDados instance;
	private String nome;
	private int codigo;
	 
	 private BancoDados() {
	    codigo = 001;
	    nome = "MySql";
	 }

	 public static BancoDados obterInstancia() {
		 if (instance == null) {
			instance = new BancoDados(); 
		 	}
		 return instance;
	 }
	 
  public String toString() { 
     return "BancoDados : " + codigo + "-" + nome + " - Instância :" + this.hashCode() ; 
  } 

}