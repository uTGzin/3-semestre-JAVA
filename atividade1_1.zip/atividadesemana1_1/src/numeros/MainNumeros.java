package numeros;
import javax.swing.JOptionPane;

public class MainNumeros {
	public static void main(String[] args) {
		String num1 = JOptionPane.showInputDialog("qual o primeiro numero : \n");
		int n1 = Integer.parseInt(num1);
		String num2 = JOptionPane.showInputDialog("qual o segundo numero : \n");
		int n2 = Integer.parseInt(num2);
		Numeros n = new Numeros(n1,n2);
		System.out.print(n.toString());
	}
}