package numeros;

public class Numeros {
	private int n1;
	private int n2;
	private int diferenca;
	private int soma;
	private float media;
	private int qtPares;
	
	Numeros(int n1, int n2) {
		this.n1 = n1;
		this.n2 = n2;
		this.soma = 0;
		this.media = 0;
		this.qtPares = 0;
		if (n1 >= n2 ) {
			this.diferenca = n1 - n2;
			for(int i = n2;i < n1;i++) {
				this.soma = this.soma + i;
				if (i%2 == 0) {
					qtPares++;
				}
			}
		}
		else {
			this.diferenca = n2 - n1;
			for(int i = n1;i < n2;i++) {
				this.soma = this.soma + i;
				if (i%2 == 0) {
					qtPares++;
				}
			}
		}
		this.media = this.soma/this.diferenca;
	}
	
	public void setN1(int n1) {
		this.n1 = n1;
	}
	
	public int getN1() {
		return this.n1;
	}
	
	public void setN2(int n2) {
		this.n2 = n2;
	}
	
	public int getN2() {
		return this.n2;
	}
	
	public int getSoma() {
		return this.soma;
	}
	
	public float getMedia() {
		return this.media;
	}
	
	public String toString() {
	String s = "Numeros : "+this.n1+" e "+this.n2+"\nsoma dos valores entre os numeros = "+this.soma;
	s = s+"\nmedia da soma = "+this.media+",quantidade de pares entre os numeros = "+this.qtPares;
	return s;
	}
}