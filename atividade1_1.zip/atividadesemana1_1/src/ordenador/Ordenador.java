package ordenador;

public class Ordenador {
	private int n1;
	private int n2;
	private int n3;
	private int aux;
	
	Ordenador(int n1, int n2, int n3){
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = n3;
		if (this.n2 < this.n1) {
			this.aux = this.n1;
			this.n1 = this.n2;
			this.n2 = this.aux;
		}
		if(this.n3 < this.n1) {
			this.aux = this.n1;
			this.n1 = this.n2;
			this.n2 = this.aux;
		}
		if(this.n3 < this.n2) {
			this.aux = this.n1;
			this.n1 = this.n2;
			this.n2 = this.aux;
		}
	}
	
	public String toString() {
		String i = "ordem crescente = "+n1+","+n2+" e "+n3+".\n";
		i = i + "ordem decerscente = "+n3+","+n2+" e "+n1+".\n";
		return i;
	}
}
