package ordenador;
import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
	 int qNum = 1;
	 Ordenador o;
	 String i = JOptionPane.showInputDialog("qual o "+qNum+"° numero ?\n");
	 int n1 = Integer.parseInt(i);
	 i = JOptionPane.showInputDialog("qual o "+qNum+"° numero?\n");
	 int n2 = Integer.parseInt(i);
	 i = JOptionPane.showInputDialog("qual o "+qNum+"° numero?\n");
	 int n3 = Integer.parseInt(i);
	 o = new Ordenador(n1,n2,n3);
	 System.out.println(o.toString());
	}
}
