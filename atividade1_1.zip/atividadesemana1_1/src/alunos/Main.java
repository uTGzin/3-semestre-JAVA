package alunos;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		int qAlunos = 0;
		String quantidade = JOptionPane.showInputDialog("quantos alunos serao adicionados ?");
		int q = Integer.parseInt(quantidade);
		Alunos a;
		ArrayList <Alunos> aluno = new ArrayList <Alunos>();
		for(int i = 0;i < q;i++) {
			qAlunos++;
			String n = JOptionPane.showInputDialog("digite o nome do "+qAlunos+"° aluno");
			String mtr = JOptionPane.showInputDialog("digite a matricula do "+qAlunos+"° aluno");
			int m = Integer.parseInt(mtr);
				a = new Alunos(n,m);
				aluno.add(a);
		}
		System.out.println("Lista de alunos cadastrados.");
		for(int i = 0;i < q;i++) {
			System.out.println(aluno.get(i).toString());
		}
	}
}