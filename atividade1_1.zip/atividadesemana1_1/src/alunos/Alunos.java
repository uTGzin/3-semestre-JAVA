package alunos;

public class Alunos {
	private String nome;
	private int matricula;
	
	Alunos(String n, int m) {
		this.nome = n;
		this.matricula = m;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getMatricula() {
		return this.matricula;
	}
	
	public String toString() {
		String s = "Aluno : "+nome+"\nMatricula : "+matricula;
		return s;
	}
}
