package implementa_testes_impostos;

public class Pessoa {
	private String nome;
	private double salario;
	private int dependentes;
	private int idade;
	
	public Pessoa(String n, double s, int d, int i) {
		this.nome = n;
		this.salario = s;
		this.dependentes = d;
		this.idade = i;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public Double getSalario() {
		return this.salario;
	}
	
	public int getDependentes() {
		return this.dependentes;
	}
	
	public int getIdade() {
		return this.idade;
	}
	
	public Double calculaImposto() {
		int i = this.idade;
		int d = this.dependentes;
		Double s = this.salario;
		if (i >= 65) {
			return 0.0;
			}
		else {	
			Double imposto = 0.0;
			Double taxa = 0.0;
			Double deducao = 0.0;
			 if(this.salario <= 1787.77) {
			 	taxa = 0.075;
			 	deducao = 134.08;
			 }
			 else if(this.salario <= 2679.29) {
				taxa = 0.15;
				deducao = 335.03;
			 }
			 else if(this.salario <= 3572.43) {
				taxa = 0.225;
				deducao = 602.96;
			 }
			 else {
				taxa = 0.275;
				deducao = 826.15;
			 }
			imposto = s*taxa - deducao;
			imposto = imposto - 179.71*d;
			if (imposto < 0) {
				imposto = 0.0;
			}
		return imposto;
		}
	}
}
