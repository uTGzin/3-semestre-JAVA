package main;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class TestaConta1 {
	public static void main(String[] args) {
		ArrayList <Conta> contas = new ArrayList <Conta>();
		int codigo = 1;
		while (codigo != 0) {
		String opcao = JOptionPane.showInputDialog("escolha o tipo de Conta:\n1 - Corrente\n2 - Salario\n3 - Poupanca\n");
		int op = Integer.parseInt(opcao);
		String c = JOptionPane.showInputDialog("digite o codigo da conta");
		codigo = Integer.parseInt(c);
		String nome = JOptionPane.showInputDialog("informe o nome : ");
		String telefone = JOptionPane.showInputDialog("informe o telefone : ");
		Cliente cli = new Cliente(nome,telefone);
		if (op == 1) {
			ContaCorrente cc = new ContaCorrente(codigo, cli);
			contas.add(cc);
		}
		else if (op == 2) {
			ContaSalario cs = new ContaSalario(codigo, cli);
			contas.add(cs);
		}
		else if (op == 3) {
			ContaPoupanca cp = new ContaPoupanca(codigo, cli);
			contas.add(cp);
		}
		for (int i = 0;i < contas.size();i++) {
			System.out.println(contas.get(i).toString());
		}
		}
	}
}
