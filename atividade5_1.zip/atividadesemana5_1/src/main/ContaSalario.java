package main;

public class ContaSalario extends ContaCorrente{
	
	ContaSalario (int n, Cliente c) {
		super(n, c);
	}
	
	public void sacar(Double s) {
		s -= 0.01;
		super.sacar(s);
	}
	
	public void depositar(Double d) {
		d -=0.01;
		super.depositar(d);
	}
	
	public void transferir(double valor, Conta destino) {
		this.sacar(valor);
		destino.depositar(valor);
	};
	
}
