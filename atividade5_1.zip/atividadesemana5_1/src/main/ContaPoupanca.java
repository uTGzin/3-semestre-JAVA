package main;

public class ContaPoupanca extends Conta{

	ContaPoupanca (int n, Cliente c) {
		super(n, c);
	}
	
	public void sacar(Double s) {
		super.sacar(s);
	}
	
	public void depositar(Double d) {
		super.depositar(d);
	}
	
	public void transferir(double valor, Conta destino) {
		this.sacar(valor);
		destino.depositar(valor);
	};
	
	public void atualizaSaldo(Double d) {
		saldo = saldo*(1+d);
	};
	
}
