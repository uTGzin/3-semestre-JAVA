package main;

public class TestaConta {
	public static void main(String[] args) {
		Cliente c = new Cliente("jairo", "982678705");
		Conta cc = new ContaCorrente(202105, c);
		Conta cp = new ContaPoupanca(202105, c);
		ContaCorrente cc1 = new ContaCorrente(202105, c);
		ContaPoupanca cp1 = new ContaPoupanca(202105, c);
		
		cc.sacar(10.00);
		System.out.println(cc.toString());
		cc.depositar(1600.00);
		System.out.println(cc.toString());
		cp.sacar(0.00);
		System.out.println(cp.toString());
		cp.depositar(150.00);
		System.out.println(cp.toString());
		cc1.sacar(0.00);
		System.out.println(cc1.toString());
		cc1.depositar(1600.00);
		System.out.println(cc1.toString());
		cp1.sacar(0.00);
		System.out.println(cp1.toString());
		cp1.depositar(150.00);
		System.out.println(cp1.toString());
		if(cp instanceof ContaPoupanca) {
			((ContaPoupanca)cp).atualizaSaldo(.10);
		}
		cp1.atualizaSaldo(.10);
		System.out.println(cp1.toString());
		
		cc.transferir(30, cp);
		System.out.println(cp.toString());
		cc1.transferir(10, cp1);
		System.out.println(cp1.toString());		
	}
}
