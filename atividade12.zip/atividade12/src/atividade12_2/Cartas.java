package atividade12_2;

public class Cartas extends Documentos{

	Cartas(int n, String r) {
		super(n, r);
	}
	
	public String toString() {
		return "Carta de "+super.toString();
	}
}
