package atividade12_2;

public class Notificacao extends Documentos{

	Notificacao(int n, String r) {
		super(n, r);
	}
	
	public String toString() {
		return "Notificacao de "+super.toString();
	}
}
