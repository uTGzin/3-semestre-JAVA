package atividade12_2;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class CadastroDocumento {
	public static void main(String args[]) {
		int t;
		Documentos doc;
		FabricaDocumentos fab = new FabricaDocumentos();
		ArrayList<Documentos> Docs = new ArrayList<>();
		while(Integer.parseInt(JOptionPane.showInputDialog("Continuar criando ?\n1 - sim\n qualquer tecla para não\n")) == 1) {
			t = Integer.parseInt(JOptionPane.showInputDialog("Qual o tipo de documento a ser fabricado?\n1 - Carta\n2 - Notificacaco\n3 - Telegrama\n(Por padrao, documentos sempre serao Telegramas\n"));
			doc = fab.criaDocumentos(Integer.parseInt(JOptionPane.showInputDialog("qual o numero do documento?")),JOptionPane.showInputDialog("Qual o remetente do documento?"), t);
			Docs.add(doc);
		}
		for (Documentos lista : Docs) {
			System.out.println(lista.toString());
		}
	}
}
