package atividade12_2;

public abstract class Documentos {
	private int numero;
	private String remetente;
	
	Documentos(int n, String r) {
		this.numero = n;
		this.remetente = r;
	}
	
	public int getNumero() {
		return this.numero;
	}
	
	public String getRemetente() {
		return this.remetente;
	}
	
	public String toString() {
		return "Numero: "+getNumero()+"\nPara: "+ getRemetente();
	}
}
