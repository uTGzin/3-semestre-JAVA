package atividade12_2;

public class FabricaDocumentos extends Fabrica{
	public Documentos criaDocumentos(int numero, String remetente, int tipo) {
		if (tipo == 1) {
			return new Cartas(numero, remetente);
		}
		else if (tipo == 2) {
			return new Notificacao(numero, remetente);
		}
		else {
			return new Telegramas(numero, remetente);
		}
	}
}
